package com.topato.moviqu;

public class DetailMovieActivity {
}
