package com.topato.moviqu;

public class Server {
    public static final String BASE_URL_API = "https://api.themoviedb.org/";

    public static BaseApi getAPIService(){
        return RetrofitClient.getClient(BASE_URL_API).create(BaseApi.class);
    }
}
